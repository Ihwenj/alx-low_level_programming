# More Functions on Pointers, Arrays and Strings.

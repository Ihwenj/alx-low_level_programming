Variables and loops

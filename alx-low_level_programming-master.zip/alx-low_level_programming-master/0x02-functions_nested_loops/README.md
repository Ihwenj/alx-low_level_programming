Functions in C

#include "main.h"
#include <stdio.h>

/**
 * add -prints add two numbers
 *@i: print int i
 *@k: print int k
 * Return: Always 0.
 */

int add(int i, int k)
{
return (i + k);
}

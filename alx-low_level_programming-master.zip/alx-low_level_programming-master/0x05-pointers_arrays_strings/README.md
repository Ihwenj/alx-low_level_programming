# Pointers, Arrays and Strings in C
